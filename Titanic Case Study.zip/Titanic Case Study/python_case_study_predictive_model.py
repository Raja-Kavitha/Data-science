"""----------------loading the dataset-------------------------"""
import pandas as pd

dataset=pd.read_csv('Titanic-Dataset.csv')
#print(dataset.head())
main_df=pd.DataFrame(dataset)
print(main_df.head())

#checking for null values
check_null=dataset.isnull().sum()
print(check_null)

"""----------Preprocessing the dataset---------------"""
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

#filling missing values
num_features=['Age','Fare']
cat_features=['Embarked']

num_transformer=Pipeline([
    ('imputer',SimpleImputer(strategy='mean')),
    ('scaler',StandardScaler())
])

cat_transformer=Pipeline([
    ('imputer',SimpleImputer(strategy='most_frequent')),
    ('onehot',OneHotEncoder())
])

preprocessor=ColumnTransformer(
    transformers=[
        ('num',num_transformer,num_features),
        ('cat',cat_transformer,cat_features)
])

transformed_df=preprocessor.fit_transform(main_df)
transformed_df=pd.DataFrame(transformed_df,columns=['Age','Fare','embarked','Survived','Sex'])
print(transformed_df)



"""
y axis--->Survived
x axis--->Sex,Age,pclass

"""
##Drop unwanted columns
print(dataset.columns)
dataset.drop(columns=['PassengerId','Name','Ticket'],inplace=True)
print(dataset.columns)
dataset.drop(columns=['Cabin'],inplace=True)
##droping the 'Cabin' column as it has too many missing values

"""
Steps for the case study

1. Load the Dataset
2. Data Pre-Processing
3. EDA--->visualizing some columns
4. Feature Engineering
5. Model Selection
6. Hyperparameter Tuning
7. Model Evaluation
8. Prediction
9. Model Interpretation

"""
"""---------------Exploratory Data Analysis---------------"""
import matplotlib.pyplot as plt
import seaborn as sns

sns.countplot(x='Survived',data=dataset)
plt.title("Survived Rate")
plt.show()

sns.countplot(x='Sex',hue='Survived',data=dataset,width=0.5)
plt.show()


"""----------------Feature engineering---------------"""
##One Hot Encoding
dataset=pd.get_dummies(dataset,columns=['Sex','Pclass','Embarked'],drop_first=True)
print(dataset)

"""---------------Model Selection--------------------"""
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

x=transformed_df.drop('Survived',axis=1)
y=transformed_df['Survived']

xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.2,random_state=42)

model=LogisticRegression()
model.fit(xtrain,ytrain)

y_predict=model.predict(xtest)
print(y_predict)

"""-----------------Model Accuracy------------------"""
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report

score=accuracy_score(ytest,y_predict)
print(score)

confusion_scr=confusion_matrix(ytest,y_predict)
print(confusion_scr)

classification_scr=classification_report(ytest,y_predict)
print(classification_scr)

"""------------------Model Interpretation---------------"""
feature_point=pd.Series(model.coef_[0],index=x.columns).sort_values(ascending=False)
feature_point.plot(kind='bar')
plt.title('Featrue importance')
plt.show()

"""
Note:coef_--->is the inbuilt of logisticregression model
"""





















